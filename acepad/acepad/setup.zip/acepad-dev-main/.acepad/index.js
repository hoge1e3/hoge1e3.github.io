/*Warning: 
Misconfiguration may cause 
this development environment itself to stop working. 
In that case, press “Setup/Restore” on the startup screen 
to start the environment for rescue, and then 
modify or delete this file. 
*/
export function config(acepad){
    acepad.setConfig({
      editor:{
          tabSize:2,
      }
    });
}