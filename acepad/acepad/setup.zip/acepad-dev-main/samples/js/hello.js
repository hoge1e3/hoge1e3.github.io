#!run

export function main(){
    this.echo("Hello acepad world!");
    this.echo("(press F1 to switch this session).");
}
/*
F5: run
F1: switch session(buffer)
*/