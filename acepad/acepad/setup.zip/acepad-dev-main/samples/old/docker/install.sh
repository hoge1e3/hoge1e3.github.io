
su
pip3 install requests
yum install unzip zip
