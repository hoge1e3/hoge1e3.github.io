cd
basync acepad
cd ~/public_html/gio/
rm -rf acepad
cp -r ~/projects/acepad .

cd ~/share/test/show
sync checkout
sh .sync/dozip
