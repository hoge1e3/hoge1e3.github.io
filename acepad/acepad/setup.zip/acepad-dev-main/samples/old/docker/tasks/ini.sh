cd /tmp
#python3 ~/bin/decode.py
#b02d3a1c7b19b9cca125ba0c1f1145d0c08aa30effbf74d9d2420970440251af
cd
npm i @hoge1e3/fs-nw
mkdir jsmod
cd jsmod
unzip /tmp/decoded.zip
cd docker
chmod 755 bin/*
cp bin/* ~/bin/
cd ..
sync
