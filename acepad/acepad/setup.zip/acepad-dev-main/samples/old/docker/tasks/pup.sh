cd
cd html/petit-node/src
sync checkout
cd ../test
sync checkout

npm run build-dev


