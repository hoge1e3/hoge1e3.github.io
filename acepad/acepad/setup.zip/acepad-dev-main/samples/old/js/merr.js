#!run 
import {test} from "petit-node";


