
imp("./modb.js").then((r)=>{
    r.dob();
},alert.bind(window));
