
globalThis.imp=(path)=>{
    return import(path);
};
