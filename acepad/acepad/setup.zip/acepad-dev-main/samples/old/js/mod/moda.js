export default function doa(){
    alert("moa/moda2?");
}