#!run 
import doa from "./moda.js";
export function main(){
    alert("mod/modb?");
    doa();
}
