import doa from "./moda.js";
import dob from "./modb.js";
export function main(){
    doa();// a
    dob();// b a
}