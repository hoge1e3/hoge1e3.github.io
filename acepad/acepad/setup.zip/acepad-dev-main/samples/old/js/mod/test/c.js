
export function c(){alert(3);}