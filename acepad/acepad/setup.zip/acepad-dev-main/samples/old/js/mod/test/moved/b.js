import {c} from '../c.js';
export function b(){c();}