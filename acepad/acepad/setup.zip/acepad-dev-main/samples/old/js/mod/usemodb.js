import * as b from "./modb.js";

b.default();