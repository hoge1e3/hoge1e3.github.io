import {FS} from "@acepad/os";
export function test(){
    alert(FS.get(__dirname).rel("modb.js").text());
}
export function toste(a){
    alert("tiste"+a);
}
//abc
///def