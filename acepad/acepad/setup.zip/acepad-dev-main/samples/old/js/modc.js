import {dob as modb} from "./mod/modb.js";
alert("mod/moda."+Object.keys(modb));


modb();