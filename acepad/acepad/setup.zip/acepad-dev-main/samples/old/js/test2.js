alert(3);
for(let e of document.querySelectorAll("img")){
    alert(e.src);
}