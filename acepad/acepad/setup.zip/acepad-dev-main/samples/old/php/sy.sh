cd ~/public_html/php
sync
exit
