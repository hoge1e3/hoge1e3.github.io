
def f(x):
    return x*5
    