
print("hoge",2+3)
def func1():
    print("fuga")