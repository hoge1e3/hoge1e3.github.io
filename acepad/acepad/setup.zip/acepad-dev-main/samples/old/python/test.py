#!python
from moda import f
for i in range(10):
    print(f(i))
