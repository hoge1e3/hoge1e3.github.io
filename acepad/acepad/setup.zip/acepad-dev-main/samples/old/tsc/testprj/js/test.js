import { n } from "tmod";
const hoge = 'hoge';
const bar = n;
const piyo = 'piyo';
function foo(d) {
    // d.getElementByIdDesu("#test");
    return bar;
}
//# sourceMappingURL=test.js.map