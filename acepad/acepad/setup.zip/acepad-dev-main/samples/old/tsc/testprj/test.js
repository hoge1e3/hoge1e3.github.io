"use strict";
const hoge = 'hoge';
const bar = 'barr';
const piyo = 'piyo';
function foo(d) {
    return 'foobarbaz';
}
//# sourceMappingURL=test.js.map