import {n} from "tmod";
const hoge = 'hoge' as any
const bar = n;
const piyo = <any>'piyo'

function foo(d:Document):string {
   // d.getElementByIdDesu("#test");
  return bar;
}