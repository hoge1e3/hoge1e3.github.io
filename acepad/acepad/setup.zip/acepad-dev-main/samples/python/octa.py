#!python
import math
A=int(input("A= "))
s=2*math.sqrt(3)*A**2
V=math.sqrt(2)/3*A**3
print ("S=",s)        
print ("V=",V)