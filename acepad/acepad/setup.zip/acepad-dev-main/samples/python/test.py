#!python 

for i in range(5):
    print(i)
print("(Press F1 to switch this session)")
# Press F5 run