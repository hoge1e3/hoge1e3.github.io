export function bfunc(x:number) {
    return x*2;
}