
export let foo=3;
export function get(){return foo;}
setInterval(()=>foo++,100);