#!run
export {main} from "/jsmod/node_modules/@hoge1e3/psync/js/cmd.js";
//import {main as m} from "/jsmod/node_modules/@hoge1e3/psync/js/cmd.js";
alert(3);
//export const main=m;
export function main2(){
    alert(5);
}.