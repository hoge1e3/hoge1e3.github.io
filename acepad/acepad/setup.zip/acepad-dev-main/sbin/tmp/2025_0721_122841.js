#!run
//aaa
export async function main(){
  const a=this.$acepad;
  const e=a.getMainEditor();
  //a.locate(0,8);
  //a.currentLine("//aaa");
  a.feed("//c");
//c

}
