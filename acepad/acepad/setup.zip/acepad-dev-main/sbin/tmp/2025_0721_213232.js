#!run
//abcdefgh
export async function main(){
   const acepad=this.$acepad;
   //cepad.locate(-2,5);
   //return acepad.lineAt(2);
   acepad.feed("//hoge");
}