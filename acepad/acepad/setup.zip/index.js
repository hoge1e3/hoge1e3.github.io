import {sh} from "@acepad/os-jsm";
import * as ace from "@acepad/with-fs";
import FS from "@hoge1e3/fs";
import {main as sug} from "@acepad/suggest";

export async function main(){
    let home=sh.resolve("/user/");
    if(!home.exists()){
        home.mkdir();
    }
    let nm=sh.resolve(import.meta.url).sibling("node_modules/");
    FS.setEnv("NODE_PATH",nm.path());
    sh.addPath(nm.rel(".bin/"));
    sh.addPath(nm.sibling("bin/"));
    sh.$home=home.path();
    
    sh.cd(home);
    await sh.copysamples();
    await ace.main.call(sh);
    await sug.call(sh);
}
main().then((s)=>0,(e)=>alert(e.stack));