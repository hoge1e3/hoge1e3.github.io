require("./sub");
alert("main");